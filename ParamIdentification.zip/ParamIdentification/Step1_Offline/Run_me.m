clear 
clc
%%%
% HOPGD based surrogate MODEL - with Sparse data
% ----------------------INPUT----------------------
% Simulation Data obtained from original models for selected parameter sets
% Present example: TWO parameters 
%                  (P1,P2) with P1~[270 300],P2~[520 540]
%                  Five datasets 
%                  (300,530),(270,530),(285,540),(285,520),(285,530)
%                  Simulation data provided by Sourav Saha at Northwestern
% ----------------------OUTPUT---------------------
% Model   Separated modes
% e       Evolution of trancation error with respect to mode number
% eB      Convergence of each mode
% -------------------------------------------------
% Copyright (C) 2020  Ye Lu
% Northwestern University, Evanston, Illinois, US, ye.lu@northwestern.edu
%%%

%--- Load selected parameter sets and corresponding data ---
load ('data/Parameter')
set=1:size(P,1);
p=P;
pset=p(set,:);
for np=1:size(pset,2)
[ps, i]=sort(pset(:,np));
   for k=1:size(ps,1)
       if k==1
           m=1;
           pd(m,np)=ps(k);
       elseif ps(k)~=ps(k-1)
           m=m+1;
           pd(m,np)=ps(k);
       end      
   end
end

%--- Assemble data into a multidimensional sparse array: X_T ------
for ns=set
    pi=[];
    name=strcat('data/S',num2str(ns)); 
    load(name)
    if ns==1
    X_T=ndSparse(zeros(size(u(:,2)))); 
    end
    pv=p(ns,:);
    for i=1:size(pv,2)
        [k]=find(pd(:,i)==pv(i));
        pi=[pi k];
    end   
    index(pi(1),pi(2))=1; 
    index=logical(index);
    %-- Final multidimensional data matrix ----
    X_T(:,:,pi(1),pi(2))=u(:,2);  
end

%---Build surrogate model using HOPGD ---------------
ec=0.01;
[ Model, e, eB] = HOPGD_axis( X_T,ec,index );
save('PGD_stress','Model','e','eB')

 


