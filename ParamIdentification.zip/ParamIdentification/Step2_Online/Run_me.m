clc
clear
%%%
% Parameter Identification using the HOPGD surrogate MODEL 
% Optimization using matlab tool box fmincon 
% Method: SQP with multiple starting guess 
% ----------------------INPUT----------------------
% pspan.mat         Parameter space
% PGD_stress.mat    HOPGD surrogate MODEL 
% Exp_ref.mat       Reference - desired behavior or experimental reference
% ----------------------OUTPUT---------------------
% Optimal paramters (P1,P2) in the parameter space 
% -------------------------------------------------
% Copyright (C) 2020  Ye Lu
% Northwestern University, Evanston, Illinois, US, ye.lu@northwestern.edu
%%%

options = optimoptions('fmincon','Algorithm','sqp','FinDiffType','central','Display','iter', 'MaxIter',30,'StepTolerance',1E-20);
FUN=@obf; % Objective function

load('pspan')
lb=ps(:,1);   % Lower bound
ub=ps(:,end); % Upper bound

%------- Online search for optimal parameters -------------------
n=10;
C=lhsdesign(n,2);
for i=1:n    
    x0= lb+(ub-lb).*C(i,:)'; % Initial guess
    [xn,fval] = fmincon(FUN,x0,[],[],[],[],lb,ub,[],options); 
    Err(i)=fval;
    p0(:,i)=x0;
    x_local(:,i)=xn;  % Local minimum
end

%------- Plot results --------------------------------------
figure
scatter(x_local(1,:),x_local(2,:),30,'o') %Local minimum
hold on
scatter(p0(1,:),p0(2,:),30,'.') % Initial guess
hold on

X_local=x_local;

[Emin,I]=min(Err);
xesti=X_local(:,I); % Optimal parameters
scatter(xesti(1),xesti(2),30,'ro')
hold on
grid off
box on
xlabel('p1')
ylabel('p2')

load('Parameter')
x=P'; % Data points
scatter(x(1,:),x(2,:),30,'k','filled')
legend('Local minimum','Initial guess', 'Best estimate for J','Data')

%--- Comparison Prediction versus Reference ----------------
name_ref='Exp_ref'; 
load(name_ref)
C1=yref; % Reference

pn=[ xesti ];
load('pspan');
name=strcat('PGD_stress');
[ W_n ] = online_prediction( name, ps, pn);
S_n = [W_n]; % Prediction with optimal parameters
load('Simu_strain')
figure
plot(xn,S_n,xn(2:end),C1(2:end),'r')
legend('Prediction','Reference')

