function [ f ] = obf( x )
name_ref='Exp_ref'; % Reference
load(name_ref)
C1=yref; % Quantity of interest
pn=[ x ];
load('pspan');
name=strcat('PGD_stress');
[ W_n ] = online_prediction( name, ps, pn);
S_n = [W_n];
R1=abs(S_n-C1);
f=norm(R1(2:end))/norm(C1(2:end)); 
end

