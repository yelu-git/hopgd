function [ x_n ] = online_prediction( name, ps, pn)
% prediction for new values of parameters
load(name)
F1=Model.F1*diag(Model.alpha);
F2=Model.F2;
for m=1:2
Fname=strcat('F',num2str(m+2));
Modeln.(Fname)=interp1(ps(m,:),Model.(Fname),pn(m),'linear');
end      
x_n=F1*diag(Modeln.F3)*diag(Modeln.F4)*F2';



end

